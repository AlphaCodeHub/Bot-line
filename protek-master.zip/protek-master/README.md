# DONE UPDATE PYTHON3
### THRIFT 0.10.0
# 1 selfbot protect
V2.1 editor_::

## instalasi via termux

apt-get install python3-pip
apt-get install python3-tz
pip3 install requests
pip3 install rsa
pip3 install bs4
pip3 install gtts
pip3 install gooslate
pip3 install googletrans
pip3 install pafy
pip3 install youtube_dl
pip3 install humanfriendly
pip3 install thrift==0.11.0
pip3 install wikiapi
